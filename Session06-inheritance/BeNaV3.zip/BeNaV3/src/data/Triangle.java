/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author pc
 */
public class Triangle extends Shape{
    private int A;
    private int B;
    private int C;
    private double p;
    private double S;
    public Triangle(String owner, String color){
        super(owner, color);
    }
    public int getPerimeter(){
        return A + B + C;
    }
    public double getp(){
         p = (A + B + C)/2;
         return p;
    }
    public double getAreaTriangle(){
        S = math.sqrt(p*(p - A)*(p - B)*(p - C));
        return S;
    }
    @Override
    public double getArea() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void paint() {
        System.out.printf("||TRIANGLE    |%-10s|%-10s|%4.1f|%4.1f|%6.2f|%6.2f|\n", A, B, C, S,  getAreaTriangle(), getPerimeter());
    }
}
